//
//  FitnessDashBoard_SwiftUIApp.swift
//  FitnessDashBoard_SwiftUI
//
//  Created by Anthony Codes on 15/03/2021.
//

import SwiftUI

@main
struct FitnessDashBoard_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
